﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProblemStatement1WebApp.Models
{
    public class PatientsModel
    {
        public string Name { get; set; }
        public string ID { get; set; }
        public string Age { get; set; }
        public string Address { get; set; }
        public string Doctor { get; set; }
        public string IsNormal { get; set; }
        public string ImageUrl { get; set; }
    }
}