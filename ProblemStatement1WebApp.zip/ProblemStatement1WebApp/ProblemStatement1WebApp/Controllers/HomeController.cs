﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ProblemStatement1WebApp.Models;

namespace ProblemStatement1WebApp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Login(LoginModel login)
        {
            
            if (ModelState.IsValid)
            {
                return RedirectToAction("Patients");
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        public ActionResult Patients()
        {
            ViewBag.Patients = PatientsList();
            return View();
        }

        public ActionResult Logout()
        {
            return RedirectToAction("Index");
        }

        public JsonResult PatientsDetails(string PatientID)
        {
            List<PatientsModel> Patients = PatientsList();
            var PatientData = Patients.Where(m => m.ID == PatientID);
            PatientsModel Patient = new PatientsModel();
            foreach(var a in PatientData)
            {
                Patient.Name = a.Name;
                Patient.Age = a.Age;
                Patient.Address = a.Address;
                Patient.Doctor = a.Doctor;
                Patient.IsNormal = a.IsNormal;
                Patient.ImageUrl = a.ImageUrl;
            }
            return Json(Patient);
        }

        public List<PatientsModel> PatientsList()
        {
            List<PatientsModel> Patients = new List<PatientsModel>();
            Patients.Add(new PatientsModel { Name = "Nikhil Kumar", ID = "1", Age = "29 Years", Address = "1/5 St. Pauls Road", Doctor = "Dr. Ashwini", IsNormal = "Normal", ImageUrl = "../Images/Patient11.png;../Images/Patient12.png;../Images/Patient13.png" });
            Patients.Add(new PatientsModel { Name = "Anil Mehta", ID = "2", Age = "67 Years", Address = "1/5 St. Pauls Road", Doctor = "Dr. Kumar", IsNormal = "Abnormal", ImageUrl = "../Images/Patient21.png" });
            Patients.Add(new PatientsModel { Name = "Vijay Yadav", ID = "3", Age = "25 Years", Address = "1/5 St. Pauls Road", Doctor = "Dr. Mehta", IsNormal = "Abnormal", ImageUrl = "../Images/Patient31.png;../Images/Patient32.png" });
            Patients.Add(new PatientsModel { Name = "Mohan Mishra", ID = "4", Age = "51 Years", Address = "1/5 St. Pauls Road", Doctor = "Dr. Arora", IsNormal = "Normal", ImageUrl = "../Images/Patient41.png;../Images/Patient42.png;../Images/Patient43.png" });
            Patients.Add(new PatientsModel { Name = "Amit Trivedi", ID = "5", Age = "78 Years", Address = "1/5 St. Pauls Road", Doctor = "Dr. Kapoor", IsNormal = "Normal", ImageUrl = "../Images/Patient51.png" });
            Patients.Add(new PatientsModel { Name = "Ranjan Jha", ID = "6", Age = "39 Years", Address = "1/5 St. Pauls Road", Doctor = "Dr. Chatterjee", IsNormal = "Abnormal", ImageUrl = "../Images/Patient61.png;../Images/Patient62.png;../Images/Patient63.png" });
            
            return Patients;
        }
    }
}