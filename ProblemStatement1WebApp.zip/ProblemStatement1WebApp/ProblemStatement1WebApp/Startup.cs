﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(ProblemStatement1WebApp.Startup))]
namespace ProblemStatement1WebApp
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
